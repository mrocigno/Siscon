@extends('default.master')
@section('title')
Distribuir serviços
@stop

@section('content')
    
    <div>
        TODO content
    </div>
    
@stop