@extends('default.master')
@section('title')
Finalizar serviços
@stop

@section('content')
    
    <div>
        TODO content
    </div>
    
@stop