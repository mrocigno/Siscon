@extends('default.master')
@section('title')
Inicio
@stop

@section('content')
    
    <div>
        TODO content
    </div>
    
@stop